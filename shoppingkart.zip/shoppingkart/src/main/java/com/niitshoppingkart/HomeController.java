package com.niitshoppingkart;

import javax.enterprise.inject.Model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.Model.User;
import com.niit.UserDAO.UserDAO;

@Controller
public class HomeController {
	//need to call methods of USERDAOimpl- so autowired
	
	@Autowired
	UserDAO userDAO;
	
	@Autowired
	User user;

	
	@RequestMapping("/")
public String homepage()
{
	return "home";
	
}
	@RequestMapping("/login")
	public ModelAndView showLoginPage()
	{//modelandview- to which page to navigate
		//what data need to be carried
		ModelAndView mv = new ModelAndView("home");
		mv.addObject("msg", "You clicked login page");
		mv.addObject("showLoginPage", "true");
		return mv;
	}
	
@RequestMapping("/register")
public ModelAndView showRegistrationPage()
{
	ModelAndView mv = new ModelAndView("home");
	mv.addObject("msg", "registration");
	mv.addObject("showRegistrationPage", "true");
	return mv;
}

@RequestMapping("/validate")
public ModelAndView validate(@RequestParam("id") String id, @RequestParam("password") String pwd){
	System.out.println("In validate Method");
	System.out.println("id:" +id);
	System.out.println("pwd:" +pwd);
	ModelAndView mv = new ModelAndView("home"); 
	
	if(userDAO.validate(id,pwd)!=null)
	{
		mv.addObject("succesmsg", "you logged in succesfully");
	}
	else
	{
		mv.addObject("errormsg", "invalidate credentials");
	}
	
	return mv;
	}
}


